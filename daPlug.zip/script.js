$(document).ready(function () {
  $(".drops").hide();
  $(".drop1").hide();
  $(".drop2").hide();
  $(".drops").slideDown(3000, function() {

    $(".drop1").slideDown(2000, function() {
      $("#dot1").slideDown(2000, function() {
        $("#dot2").slideDown(2000);
        $("#dot3").slideDown(2000);
      });    
      
    });

    $(".drop2").slideDown(1000, function() {
      $(".drop2").show();
      
    });
    
    
         
  });
  
  
});









